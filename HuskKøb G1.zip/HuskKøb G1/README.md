# HuskKøb

HuskKøb er en simpel React Native-app til at oprette og holde styr på en indkøbsliste.

## Om appen

Appen er lavet til Godkendelsesopgave 1 i Innovation og Ny Teknologi på CBS. Den har tre sider: Forside, Indkøbsliste og Om appen.

## Funktioner

- Åbn indkøbslisten eller vejledningen fra forsiden.
- Start med eksempelvarerne Havregryn, Tomater og Pasta.
- Skriv en vare og tryk på Tilføj vare. Inputfeltet tømmes bagefter.
- Tom tekst og tekst med kun mellemrum bliver ikke tilføjet.
- Se varerne i en FlatList og følg antallet med tælleren.
- Tøm hele listen med Ryd listen.

Varerne ligger kun i sidens useState. De nulstilles, når siden åbnes på ny efter at være lukket med tilbageknappen, eller når appen genstartes. Der bruges ingen permanent lagring.

## Teknologier

Appen bruger JavaScript, React Native og Expo. React Navigation og Native Stack står for navigationen. React Native Screens og Safe Area Context er nødvendige pakker til navigationen. Styling ligger i en separat fil med StyleSheet.create(), og kodekommentarerne er på dansk.

## Installation

Installer Node.js med npm på computeren. Projektets React Native-version kræver Node.js 20.19.4+, 22.13.0+ eller 24.3.0+ inden for de pågældende hovedversioner (eller Node.js 25+). Til afprøvning på telefon skal du også installere Expo Go.

Åbn en terminal i projektmappen og kør:

```sh
npm install
```

## Sådan startes appen

Start i browseren:

```sh
npm run web
```

Expo åbner webappen i din browser. Web-understøttelsen bruger `react-dom`, `react-native-web` og `@expo/metro-runtime`, som installeres med `npm install`.

Start på telefon:

```sh
npx expo start
```

Telefon og computer skal være på samme Wi-Fi. Scan QR-koden med telefonens kamera på iPhone eller via Expo Go på Android. Brug en Expo Go-version, der understøtter projektets Expo SDK.

## Projektstruktur

```text
App.js                         Navigation og registrering af tre sider
index.js                       Starter appen i Expo
app.json                       Appens navn og Expo-indstillinger
screens/
    HomeScreen.js              Forside med to navigationsknapper
    ShoppingListScreen.js      Input, state, vareliste og tæller
    AboutScreen.js             Beskrivelse og vejledning
styles/
    GlobalStyle.js             Fælles styling og farver
assets/                        Billeder fra Expos blanke skabelon
package.json                   Pakker og startkommandoer
package-lock.json              Fastlåste pakkeversioner
.gitignore                     Udelukker blandt andet node_modules
README.md                      Beskrivelse og startvejledning
```

Den eksisterende tomme fil hej.js bruges ikke af appen.

## Afprøvning

JavaScript/JSX-syntaksen er kontrolleret i alle seks kodefiler. Listens funktioner er afprøvet med simuleret state, og Expo har bekræftet, at de installerede pakkeversioner passer sammen. Navigationens sidenavne, imports og exports er gennemgået.

Web-build er kontrolleret med `npx expo export --platform web` på Node.js 24.21.0 og gennemført uden fejl. Det genererede website ligger i `dist/`. Appen er ikke afprøvet på en telefon.

Brug denne tjekliste i Expo Go:

1. Åbn appen, tryk på Om appen, og gå tilbage til forsiden.
2. Tryk på Åbn indkøbsliste. Der skal stå tre eksempelvarer og Antal varer: 3.
3. Tilføj en vare. Den skal vises i listen, tælleren skal stige, og inputfeltet skal blive tomt.
4. Prøv at tilføje et tomt felt og derefter kun mellemrum. Antallet skal være uændret.
5. Tryk på Ryd listen. Tælleren skal vise 0, og en besked om den tomme liste skal vises.
6. Tilføj en vare igen for at kontrollere, at listen stadig virker.

## Demovideo

Demovideo:
[INDSÆT LINK TIL DEMOVIDEO HER]
